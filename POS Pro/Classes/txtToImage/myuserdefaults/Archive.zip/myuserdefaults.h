//
//  myuserdefaults.h
//  pos
//
//  Created by Khaled on 1/20/20.
//  Copyright © 2020 khaled. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDB.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^resultCompletionBlock)(id data);


@interface myuserdefaults : NSObject


@property(nonatomic,strong)  FMDatabase *db;
@property(nonatomic,strong)  FMDatabaseQueue *Queue_db;



+(NSString *) printPath;

+(BOOL) isitems:(NSString *) ItemID   Prefix:(NSString*) Prefix;

+(NSArray *) lstitems:(NSString*) Prefix;

+(void) Setitems:(NSString *)ItemID SetValue:(id) dic  Prefix:(NSString*) Prefix;
+(id) getitem:(NSString *)ItemID   Prefix:(NSString*) Prefix;

+(void) deleteAll:(NSArray *) ignoreFiles;
+(void) Deletelstitems:(NSString*) Prefix;
+(void) deleteitems:(NSString *)ItemID   Prefix:(NSString*) Prefix;

@end

NS_ASSUME_NONNULL_END
