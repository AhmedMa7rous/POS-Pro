//
//  myuserdefaults.m
//  pos
//
//  Created by Khaled on 1/20/20.
//  Copyright © 2020 khaled. All rights reserved.
//

#import "myuserdefaults.h"
#import "JsonToDictionary.h"

//FMDatabase *cash_db;

@implementation myuserdefaults

+(FMDatabase *) cash_db
{
    [sharedInstance.Queue_db inDatabase:^(FMDatabase * _Nonnull db) {
         
    }];
    
    FMDatabase *db = [self sharedManager].db ;
//    [db  close];
//    [db open] ;
    
    return db ;
}
 
static myuserdefaults *sharedInstance = nil;

 + (myuserdefaults *)sharedManager
 {
     if (sharedInstance == nil)
     {
         static dispatch_once_t  oncePredecate;

           dispatch_once(&oncePredecate,^{
               sharedInstance=[[myuserdefaults alloc] init];

            });
         
        
         
     }
     
     
  if (sharedInstance.Queue_db == nil)
          {
              sharedInstance.Queue_db = [ myuserdefaults checkDataBase];
          }
     
   return sharedInstance;
 }

//- (id)init {
//  if (self = [super init]) {
//      _db = [myuserdefaults checkDataBase] ;
//  }
//  return self;
//}

+(FMDatabaseQueue *) getDatabase:(NSString *) filePath
{
 //
  //  FMDatabase *db = [FMDatabase databaseWithPath:filePath];
    FMDatabaseQueue *queue = [FMDatabaseQueue databaseQueueWithPath:filePath];

 
//    if (![db open]) {
//        // [db release];   // uncomment this line in manual referencing code; in ARC, this is not necessary/permitted
//        db = nil;
//
//    }
    
 
    
//    cash_db = db ;
  
    return queue ;
  
}

+(FMDatabaseQueue *) checkDataBase
{
       NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
       NSString *documentsPath = [paths objectAtIndex:0];
    
       NSString *filePath = [documentsPath stringByAppendingPathComponent:@"cash.db"];

        NSFileManager *fileManager = [NSFileManager defaultManager];
           if ( ![fileManager fileExistsAtPath:filePath] ) {
               
             NSString*  fromPath = [[[NSBundle mainBundle] resourcePath ]stringByAppendingPathComponent:@"cash.db"];
               
               [fileManager copyItemAtPath:fromPath toPath:filePath error:nil];
           }
     
    return  [self getDatabase:filePath];
}

+(NSString *) printPath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
 
 
       NSLog(@"path : %@" , [NSString stringWithFormat:@"%@" ,documentsPath] );
    return  [NSString stringWithFormat:@"%@" ,documentsPath] ;
}



+(BOOL) isitems:(NSString *) ItemID   Prefix:(NSString*) Prefix {
    NSArray *arr = [NSArray arrayWithObjects:ItemID,Prefix, nil];
    
  __block  BOOL exist =false;
    
    [sharedInstance.Queue_db inDatabase:^(FMDatabase *db) {
        
        FMResultSet *s = [[self cash_db] executeQuery:@"SELECT COUNT(*) FROM cash where key=? and Prefix=?" withArgumentsInArray:arr];
           if ([s next]) {
               int totalCount = [s intForColumnIndex:0];
               if (totalCount > 0)
               {
                   exist = YES;
               }
               
                  [s close];
           }
           
            [s close];
    }];
   
    return exist;
}

+(NSArray *) lstitems:(NSString*) Prefix {
    
    NSMutableArray *lst = [[NSMutableArray alloc] init];
    
    NSArray *arr = [NSArray arrayWithObjects:Prefix, nil];
    
    FMResultSet *s = [[self cash_db] executeQuery:@"SELECT * FROM cash where  Prefix=?" withArgumentsInArray:arr];
    
    while ([s next]) {
        //retrieve values for each record
        NSString *st = [s stringForColumn:@"data"];
        [lst addObject:st];
    }
       [s close];
    
    return lst;
}

+(void) Setitems:(NSString *)ItemID SetValue:(id) dic  Prefix:(NSString*) Prefix {
    
    BOOL isExist = [self isitems:ItemID Prefix:Prefix];
    
    NSString *jsonString = [self JSONString:dic prettyPrinted:true];
    
    FMDatabase *database = [self cash_db];
    
    if ( isExist == NO) {
        NSString *sql = @"insert into cash (key,Prefix,data) values (?,?,?)" ;
           
           BOOL success = [database executeUpdate:sql, ItemID, Prefix, jsonString];
           if (!success) {
               NSLog(@"error = %@", [database lastErrorMessage]);
           }
    }
    else
    {
        NSString *sql = @"update cash set  data = ? where key=? and Prefix=?  " ;
        
        BOOL success = [database executeUpdate:sql, jsonString,ItemID, Prefix ];
        if (!success) {
            NSLog(@"error = %@", [database lastErrorMessage]);
        }
        
    }
    

   
    
}

+(void) getitem:(NSString *)ItemID   Prefix:(NSString*) Prefix completionAction:(resultCompletionBlock) completionBlock
{
//    FMDatabase *database = [self cash_db];

    __block id object= nil;
    
  [sharedInstance.Queue_db inDatabase:^(FMDatabase *db) {
        
    FMResultSet *s = [db executeQuery:@"SELECT * FROM cash where key=? and Prefix=?" , ItemID,Prefix];
    if ([s next]) {
        
        NSString *stringJson = [s stringForColumn:@"data"];
        NSData *data = [stringJson dataUsingEncoding:NSUTF8StringEncoding];

        id value =  [NSJSONSerialization JSONObjectWithData:data   options:0  error:nil];
         if (value == nil)
         {
             object = stringJson;
         }
        else
        {
              object =  value;
        }
    }
      [s close];
      
      completionBlock(object);
            
    }];
    
 
}

+(void) deleteAll:(NSArray *) ignoreFiles {
    
    FMDatabase *database = [self cash_db];

    
    NSString *where = @"" ;
    
    for (int i= 0; i < ignoreFiles.count ; i++) {
        if (i == 0)
        {
            where = [NSString stringWithFormat:@" Prefix !='%@'"  , [ignoreFiles objectAtIndex:i]];

        }
        else
        {
            where = [NSString stringWithFormat:@"%@ and Prefix !='%@'" , where , [ignoreFiles objectAtIndex:i]];

        }
    }
    
    if (![where isEqualToString:@""])
    {
       where = [NSString stringWithFormat:@"where '%@'" , where  ];

    }
    
    NSString *sql = [NSString stringWithFormat:@"%@ %@" , @"delete from cash  " , where] ;
              
              BOOL success = [database executeUpdate:sql ];
              if (!success) {
                  NSLog(@"error = %@", [database lastErrorMessage]);
              }
}

+(void) Deletelstitems:(NSString*) Prefix {
        FMDatabase *database = [self cash_db];
    
    NSString *sql = @"delete from cash where  Prefix=? " ;
           
           BOOL success = [database executeUpdate:sql,   Prefix ];
           if (!success) {
               NSLog(@"error = %@", [database lastErrorMessage]);
           }
}

+(void) deleteitems:(NSString *)ItemID   Prefix:(NSString*) Prefix
{
     FMDatabase *database = [self cash_db];
    
    NSString *sql = @"delete from cash where key=? and Prefix=?  " ;
           
           BOOL success = [database executeUpdate:sql,  ItemID, Prefix ];
           if (!success) {
               NSLog(@"error = %@", [database lastErrorMessage]);
           }
           
}

+ (NSString*)JSONString:(id)dictionary prettyPrinted:(BOOL)prettyPrinted
{
    if ([dictionary isKindOfClass:[NSString class]])
    {
        return dictionary ;
    }
    
    
    NSJSONWritingOptions options = (prettyPrinted) ? NSJSONWritingPrettyPrinted : 0;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:options error:nil];
    return  [[NSString alloc] initWithBytes:[jsonData bytes] length:[jsonData length] encoding:NSUTF8StringEncoding];
}

@end
